Smart Contract
This project demonstrates a basic Hardhat use case. It comes with a sample contract, a test for the smart contract, a sample script that deploys the contract, and an example of a task implementation, which simply lists the available accounts.
