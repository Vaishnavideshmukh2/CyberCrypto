import abi from "./Transactions.json";

export const contractAddress = "0x13aB2F07e394822bdfDac04235B3Eba2E717461E";
//export const contractABI = "i3i3i3i33ii3";
export const contractABI = abi.abi;